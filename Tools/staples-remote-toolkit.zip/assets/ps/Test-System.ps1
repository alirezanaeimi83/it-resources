# Self elevate script
param([switch]$Elevated)

function Test-Admin {
    $currentUser = New-Object Security.Principal.WindowsPrincipal $([Security.Principal.WindowsIdentity]::GetCurrent())
    $currentUser.IsInRole([Security.Principal.WindowsBuiltinRole]::Administrator)
}

if ((Test-Admin) -eq $false)  {
    if ($elevated) {
    # could not elevate, quit
    }
    
    else {
        Start-Process PowerShell -Verb RunAs -ArgumentList ('-NoProfile -ExecutionPolicy Bypass -NoExit -File "{0}" -Elevated' -f ($myinvocation.MyCommand.Definition))
    }

exit
}

#REQUIRES -Version 2.0

<#
.SYNOPSIS
    Test disk partition for errors and system files for integrity violations.
.DESCRIPTION
    ### TODO ### 
    A detailed description of the function or script. This keyword can be
    used only once in each topic.
.NOTES
    File Name      : Get-File.ps1
    Author         : Justin Chapdelaine (@email)
    Prerequisite   : PowerShell V2 for Windows 7 and up.
.LINK
    Toolkit posted at:
    https://github.com/justinchapdelaine/staples-remote-toolkit
#>


# Check disk partition for errors
chkdsk

# Check system files for integirty violations
sfc /verifyonly