#REQUIRES -Version 2.0

<#
.SYNOPSIS
    Download a file and execute.
.DESCRIPTION
    ### TODO ### 
    A detailed description of the function or script. This keyword can be
    used only once in each topic.
.NOTES
    File Name      : Get-File.ps1
    Author         : Justin Chapdelaine (@email)
    Prerequisite   : PowerShell V2 for Windows 7 and up.
.LINK
    Toolkit posted at:
    https://github.com/justinchapdelaine/staples-remote-toolkit
#>

param (
    # Url of the download
    [Parameter(Mandatory)]
    [string]
    $url = " ",

    # Path to save file
    [Parameter(Mandatory)]
    [string]
    $path = " "
)

# Test $path doesn't already exist 
if(![System.IO.File]::Exists($path)){

    # Create new directory for file
    if(![System.IO.File]::Exists('C:\STS\Programs')){
        New-Item -ItemType directory -Path C:\STS\Programs
    }

    # Download the tool from $url to $path
    (New-Object Net.WebClient).DownloadFile("$url", "$path")
}

# Start file $path
Start-Process $path
