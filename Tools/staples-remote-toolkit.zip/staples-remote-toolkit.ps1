#REQUIRES -Version 2.0

<#
.SYNOPSIS
    Toolkit for common task during remove service.
.DESCRIPTION
    ### TODO ### 
    A detailed description of the function or script. This keyword can be
    used only once in each topic.
.NOTES
    File Name      : staples-remote-toolkit.ps1
    Author         : Justin Chapdelaine (@email)
    Prerequisite   : PowerShell V2 for Windows 7 and up.
.LINK
    Toolkit posted at:
    https://github.com/justinchapdelaine/staples-remote-toolkit
#>

# Enable WPF (Windows Presentation Framework) in PowerShell
Add-Type -AssemblyName PresentationFramework

#region GUI
[xml]$xaml = @"
<Window
        xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        xmlns:d="http://schemas.microsoft.com/expression/blend/2008"
        xmlns:mc="http://schemas.openxmlformats.org/markup-compatibility/2006"
        x:Name="window"
        Title="Staples Remote Toolkit" Height="600" Width="800">

    <Grid x:Name="Grid">
        
        <Grid.RowDefinitions>
            <RowDefinition Height="Auto" />
            <RowDefinition Height="Auto" />
            <RowDefinition Height="Auto" />
            <RowDefinition Height="Auto" />
            <RowDefinition Height="Auto" />
            <RowDefinition Height="Auto" />
            <RowDefinition Height="Auto" />
            <RowDefinition Height="Auto" />
            <RowDefinition Height="Auto" />
            <RowDefinition Height="Auto" />
            <RowDefinition Height="Auto" />

        </Grid.RowDefinitions>
        <Grid.ColumnDefinitions>
            <ColumnDefinition Width="Auto" />
            <ColumnDefinition Width="Auto" />
            <ColumnDefinition Width="Auto" />
            <ColumnDefinition Width="Auto" />
        </Grid.ColumnDefinitions>

        <TextBlock x:Name="Shortcuts" Grid.Column="0" Grid.Row="0" HorizontalAlignment="Left" Margin="10" TextWrapping="Wrap" Text="Shortcuts:" VerticalAlignment="Top" FontWeight="Bold" FontSize="16"/>
        <Button x:Name="windowsUpdate" Content="Windows Update" Grid.Column="0" Grid.Row="1" HorizontalAlignment="Left" Margin="20,5,5,5" VerticalAlignment="Top" Width="100"/>
        <Button x:Name="deviceManager" Content="Device Manager" Grid.Column="1" Grid.Row="1" HorizontalAlignment="Left" Margin="20,5,5,5" VerticalAlignment="Top" Width="100"/>
        <Button x:Name="stsFolder" Content="STS Folder" Grid.Column="2" Grid.Row="1" HorizontalAlignment="Left" Margin="20,5,5,5" VerticalAlignment="Top" Width="100"/>
        <Button x:Name="apps" Content="Apps" Grid.Column="0" Grid.Row="2" HorizontalAlignment="Left" Margin="20,5,5,5" VerticalAlignment="Top" Width="100"/>
        <Button x:Name="msconfig" Content="Msconfig" Grid.Column="1" Grid.Row="2" HorizontalAlignment="Left" Margin="20,5,5,5" VerticalAlignment="Top" Width="100"/>
        <Button x:Name="reliabilityHistory" Content="Reliability History" Grid.Column="2" Grid.Row="2" HorizontalAlignment="Left" Margin="20,5,5,5" VerticalAlignment="Top" Width="100"/>
        <Button x:Name="accounts" Content="Accounts" Grid.Column="0" Grid.Row="3" HorizontalAlignment="Left" Margin="20,5,5,5" VerticalAlignment="Top" Width="100"/>
        <Button x:Name="eventViewer" Content="Event Viewer" Grid.Column="1" Grid.Row="3" HorizontalAlignment="Left" Margin="20,5,5,5" VerticalAlignment="Top" Width="100"/>

        <TextBlock x:Name="Scripts" Grid.Column="0" Grid.Row="4" HorizontalAlignment="Left" Margin="10" TextWrapping="Wrap" Text="Scripts:" VerticalAlignment="Top" FontWeight="Bold" FontSize="16"/>
        <Button x:Name="debloat" Content="Debloat" Grid.Column="0" Grid.Row="5" HorizontalAlignment="Left" Margin="20,5,5,5" VerticalAlignment="Top" Width="100"/>
        <Button x:Name="iconsTime" Content="Icons and Time" Grid.Column="1" Grid.Row="5" HorizontalAlignment="Left" Margin="20,5,5,5" VerticalAlignment="Top" Width="100"/>
        <Button x:Name="setTiles" Content="Set Tiles" Grid.Column="2" Grid.Row="5" HorizontalAlignment="Left" Margin="20,5,5,5" VerticalAlignment="Top" Width="100"/>

        <TextBlock x:Name="Tools" Grid.Column="0" Grid.Row="6" HorizontalAlignment="Left" Margin="10" TextWrapping="Wrap" Text="Tools:" VerticalAlignment="Top" FontWeight="Bold" FontSize="16"/>
        <Button x:Name="rKill" Content="rKill" Grid.Column="0" Grid.Row="7" HorizontalAlignment="Left" Margin="20,5,5,5" VerticalAlignment="Top" Width="100"/>
        <Button x:Name="adwCleaner" Content="AdwCleaner" Grid.Column="1" Grid.Row="7" HorizontalAlignment="Left" Margin="20,5,5,5" VerticalAlignment="Top" Width="100"/>
        <Button x:Name="kvrt" Content="KVRT" Grid.Column="2" Grid.Row="7" HorizontalAlignment="Left" Margin="20,5,5,5" VerticalAlignment="Top" Width="100"/>
        <Button x:Name="testSystem" Content="Test System" Grid.Column="0" Grid.Row="8" HorizontalAlignment="Left" Margin="20,5,5,5" VerticalAlignment="Top" Width="100"/>
        <Button x:Name="repairSystem" Content="Repair System" Grid.Column="1" Grid.Row="8" HorizontalAlignment="Left" Margin="20,5,5,5" VerticalAlignment="Top" Width="100"/>


        <TextBlock x:Name="Installers" Grid.Column="0" Grid.Row="9" HorizontalAlignment="Left" Margin="10" TextWrapping="Wrap" Text="Installers:" VerticalAlignment="Top" FontWeight="Bold" FontSize="16"/>
                        
        <StackPanel Margin="2,5,5,5" Grid.Column="0" Grid.Row="10" Orientation="Vertical">
            <CheckBox x:Name="chrome" Margin="15,2,2,2">Google Chrome</CheckBox>
            <CheckBox x:Name="firefox" Margin="15,2,2,2">Mozilla Firefox</CheckBox>
            <CheckBox x:Name="java" Margin="15,2,2,2">Java</CheckBox>
            <CheckBox x:Name="nortonDeluxe" Margin="15,2,2,2">Norton Deluxe</CheckBox>
        </StackPanel>

        <StackPanel Margin="10,5,5,5" Grid.Column="1" Grid.Row="10" Orientation="Vertical">
            <CheckBox x:Name="vlc" Margin="2">VLC Media Player</CheckBox>
            <CheckBox x:Name="adobeReader" Margin="2">Adobe Reader DC</CheckBox>
            <CheckBox x:Name="sevenZip" Margin="2">7-zip File Manager</CheckBox>
            <CheckBox x:Name="mcafeeLive" Margin="2">McAfee LiveSafe</CheckBox>
        </StackPanel>

        <StackPanel Margin="10,5,5,5" Grid.Column="2" Grid.Row="10" Orientation="Vertical">
            <CheckBox x:Name="malwarebytes" Margin="2">Malwarebytes</CheckBox>
            <CheckBox x:Name="kasperskyInternet" Margin="2">Kaspersky Internet</CheckBox>
            <CheckBox x:Name="nortonPremium" Margin="2">Norton Premium</CheckBox>
        </StackPanel>

        <TextBox x:Name="InfoTextBox" Width="350" Grid.Column="3" Grid.Row="0" Grid.RowSpan="4" Margin="20.5,21.5,20.5,8" />
        <TextBox x:Name="OutputTextBox" Width="350" Grid.Column="3" Grid.Row="4" Grid.RowSpan="7" Margin="22.5,10,22.5,-69.107" />

    </Grid>
</Window>
"@
#endregion

$reader = (New-Object System.Xml.XmlNodeReader $xaml)
$window = [Windows.Markup.XamlReader]::Load($reader)

#region Shortcuts

# Windows Update
$window.FindName("windowsUpdate").add_Click({
    explorer ms-settings:windowsupdate
})

# Device Manager
$window.FindName("deviceManager").add_Click({
    Start-Process devmgmt.msc
})

# STS Folder
$window.FindName("stsFolder").add_Click({
    explorer C:\STS\
})

# Apps & Features
$window.FindName("apps").add_Click({
    explorer ms-settings:appsfeatures
})

# Msconfig
$window.FindName("msconfig").add_Click({
    Start-Process msconfig
})

# Reliability History
$window.FindName("reliabilityHistory").add_Click({
    Start-Process perfmon.exe /rel
})

# Accounts
$window.FindName("accounts").add_Click({
    explorer ms-settings:otherusers
})

# Event Viewer
$window.FindName("eventViewer").add_Click({
    Start-Process eventvwr.msc
})

#endregion

#region Tools

# rKill
$window.FindName("rKill").add_Click({
    $url = "http://download.bleepingcomputer.com/grinler/rkill.exe"
    $path = "C:\STS\Programs\rKill.exe"
    
    Start-Process PowerShell -WindowStyle Hidden -ArgumentList "-NoProfile -File .\assets\ps\Get-File.ps1", "$url", "$path"
})

# AdwCleaner
$window.FindName("adwCleaner").add_Click({
    $url = "https://download.toolslib.net/download/direct/1/latest?channel=release"
    $path = "C:\STS\Programs\AdwCleaner.exe"
    
    Start-Process PowerShell -WindowStyle Hidden -ArgumentList "-NoProfile -File .\assets\ps\Get-File.ps1", "$url", "$path"
})

# Kaspersky Virus Removal Tool
$window.FindName("kvrt").add_Click({
    $url = "http://devbuilds.kaspersky-labs.com/devbuilds/KVRT/latest/full/KVRT.exe"
    $path = "C:\STS\Programs\KVRT.exe"
    
    Start-Process PowerShell -WindowStyle Hidden -ArgumentList "-NoProfile -File .\assets\ps\Get-File.ps1", "$url", "$path"
})

# Check disk partition for errors and system files for integrity violations
$window.FindName("testSystem").add_Click({
    Start-Process PowerShell -ArgumentList "-NoProfile -File .\assets\ps\Test-System.ps1"
})

# Check disk partition for errors and system files for integrity violations
$window.FindName("repairSystem").add_Click({
    Start-Process PowerShell -ArgumentList "-NoProfile -File .\assets\ps\Repair-System.ps1"
})

#endregion

#region Installers

# Google Chrome
$window.FindName("chrome").add_Checked({
    $url = "https://dl.google.com/chrome/install/latest/chrome_installer.exe"
    $path = "C:\STS\Programs\Google_Chrome.exe"
    
    Start-Process PowerShell -WindowStyle Hidden -ArgumentList "-NoProfile -File .\assets\ps\Get-File.ps1", "$url", "$path"
})

# Mozilla Firefox
$window.FindName('firefox').add_Checked({
    $url = "https://download.mozilla.org/?product=firefox-latest&os=win64&lang=en-CA"
    $path = "C:\STS\Programs\Mozilla_Firefox.exe"

    Start-Process PowerShell -WindowStyle Hidden -ArgumentList "-NoProfile -File .\assets\ps\Get-File.ps1", "$url", "$path"
})

# Java
$window.FindName('java').add_Checked({
    $url = "https://javadl.oracle.com/webapps/download/AutoDL?BundleId=238726_478a62b7d4e34b78b671c754eaaf38ab"
    $path = "C:\STS\Programs\Java.exe"

    Start-Process PowerShell -WindowStyle Hidden -ArgumentList "-NoProfile -File .\assets\ps\Get-File.ps1", "$url", "$path"
})

# Norton Deluxe
$window.FindName('nortonDeluxe').add_Checked({
    $url = "https://lcdls.symantec.com/93639012/AynW7R0BGKNVU00FOAUEbimf+/AbcX003MD/////%2F%26%7E%2F%26%7E%2F%26%7E%2F%26%7E%2F%26%7E%2F%26%7E%2F%26%7E%2F%26%7E%2F%26%7E%2F%26%7E/NSDownloader.exe?LNG=eng-USA&latest=true"
    $path = "C:\STS\Programs\Norton_Deluxe.exe"

    Start-Process PowerShell -WindowStyle Hidden -ArgumentList "-NoProfile -File .\assets\ps\Get-File.ps1", "$url", "$path"
})

# VLC Media Player
$window.FindName('vlc').add_Checked({
    $url = "https://get.videolan.org/vlc/3.0.7.1/win64/vlc-3.0.7.1-win64.exe"
    $path = "C:\STS\Programs\VLC.exe"

    Start-Process PowerShell -WindowStyle Hidden -ArgumentList "-NoProfile -File .\assets\ps\Get-File.ps1", "$url", "$path"
})

# Adobe Reader DC
$window.FindName('adobeReader').add_Checked({
    $url = "http://ardownload.adobe.com/pub/adobe/reader/win/AcrobatDC/1901220034/AcroRdrDC1901220034_en_US.exe"
    $path = "C:\STS\Programs\Adobe_Reader_DC.exe"

    Start-Process PowerShell -WindowStyle Hidden -ArgumentList "-NoProfile -File .\assets\ps\Get-File.ps1", "$url", "$path"
})

# 7-zip File Manager
$window.FindName('sevenZip').add_Checked({
    $url = "https://www.7-zip.org/a/7z1900-x64.exe"
    $path = "C:\STS\Programs\7zip.exe"

    Start-Process PowerShell -WindowStyle Hidden -ArgumentList "-NoProfile -File .\assets\ps\Get-File.ps1", "$url", "$path"
})

# McAfee LiveSafe
$window.FindName('mcafeeLive').add_Checked({
    $url = "https://www.mcafee.com/consumer/en-us/site-configurations/external-link/product/mls-download.html?culture=en-us&cctype=m0&affid=0&ccstype=others&cseg=no-segment&cexp=no-experience&ccta=mls_430%3a30dt%3aofferprice%3acurrencycode%3ab1b1&ccpubn=en-us%3ad%3astore%3am0%3acatalog%3amls_430%3astubfreetrial%40no-segment%40mls_430%3a30dt%3aofferprice%3acurrencycode%3ab1b1&ccpun=en-us%3ad%3astore%3am0%3acatalog%3amls_430%3astubfreetrial%40no-segment&ccpn=en-us%3ad%3astore%3am0%3acatalog%3amls_430%3astubfreetrial"
    $path = "C:\STS\Programs\McAfee_LifeSafe.exe"

    Start-Process PowerShell -WindowStyle Hidden -ArgumentList "-NoProfile -File .\assets\ps\Get-File.ps1", "$url", "$path"
})

# Malwarebytes Anti-Malware
$window.FindName('malwarebytes').add_Checked({
    $url = "https://downloads.malwarebytes.com/file/mb3"
    $path = "C:\STS\Programs\Malwarebytes.exe"

    Start-Process PowerShell -WindowStyle Hidden -ArgumentList "-NoProfile -File .\assets\ps\Get-File.ps1", "$url", "$path"
})

# Kaspersky Internet Security
$window.FindName('kasperskyInternet').add_Checked({
    $url = "https://trial.s.kaspersky-labs.com/registered/oaavni0cztkt4nb17kzs/27c9b336/startup_14442.exe"
    $path = "C:\STS\Programs\Kaspersky_Internet_Security.exe"

    Start-Process PowerShell -WindowStyle Hidden -ArgumentList "-NoProfile -File .\assets\ps\Get-File.ps1", "$url", "$path"
})

# Norton Premium
$window.FindName('nortonPremium').add_Checked({
    $url = "https://lcdls.symantec.com/93639012/CXlwMQ0HR9DNR00RSDTAVsy/+/Abcb003MD/////%2F%26%7E%2F%26%7E%2F%26%7E%2F%26%7E%2F%26%7E%2F%26%7E%2F%26%7E%2F%26%7E%2F%26%7E%2F%26%7E/NSBUDownloader.exe?LNG=eng-USA&latest=true"
    $path = "C:\STS\Programs\Norton_Premium.exe"

    Start-Process PowerShell -WindowStyle Hidden -ArgumentList "-NoProfile -File .\assets\ps\Get-File.ps1", "$url", "$path"
})

#endregion

#region EOF
$window.ShowDialog() | Out-Null
#endregion