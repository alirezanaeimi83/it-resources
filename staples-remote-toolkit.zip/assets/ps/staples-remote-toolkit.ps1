<# 
.NAME
    Staples Remote Toolkit
#>

########################## GUI Code ##########################

Add-Type -AssemblyName System.Windows.Forms
[System.Windows.Forms.Application]::EnableVisualStyles()

$staplesRemoteToolkit            = New-Object system.Windows.Forms.Form
$staplesRemoteToolkit.ClientSize  = '1000,800'
$staplesRemoteToolkit.text       = "Staples Remote Toolkit"
$staplesRemoteToolkit.TopMost    = $false
$staplesRemoteToolkit.icon       = "./assets/icon/staples-icon.ico"

$shortcuts                       = New-Object system.Windows.Forms.Label
$shortcuts.text                  = "Shotcuts:"
$shortcuts.AutoSize              = $true
$shortcuts.width                 = 25
$shortcuts.height                = 10
$shortcuts.location              = New-Object System.Drawing.Point(20,20)
$shortcuts.Font                  = 'Microsoft Sans Serif,14,style=Bold'

$windowsUpdate                   = New-Object system.Windows.Forms.Button
$windowsUpdate.text              = "Windows Update"
$windowsUpdate.width             = 120
$windowsUpdate.height            = 30
$windowsUpdate.location          = New-Object System.Drawing.Point(30,60)
$windowsUpdate.Font              = 'Microsoft Sans Serif,10'

$deviceManager                   = New-Object system.Windows.Forms.Button
$deviceManager.text              = "Device Manager"
$deviceManager.width             = 120
$deviceManager.height            = 30
$deviceManager.location          = New-Object System.Drawing.Point(200,60)
$deviceManager.Font              = 'Microsoft Sans Serif,10'

$stsFolder                       = New-Object system.Windows.Forms.Button
$stsFolder.text                  = "STS Folder"
$stsFolder.width                 = 120
$stsFolder.height                = 30
$stsFolder.location              = New-Object System.Drawing.Point(370,60)
$stsFolder.Font                  = 'Microsoft Sans Serif,10'

$appsFeatures                    = New-Object system.Windows.Forms.Button
$appsFeatures.text               = "Apps"
$appsFeatures.width              = 120
$appsFeatures.height             = 30
$appsFeatures.location           = New-Object System.Drawing.Point(30,100)
$appsFeatures.Font               = 'Microsoft Sans Serif,10'

$accounts                        = New-Object system.Windows.Forms.Button
$accounts.text                   = "Accounts"
$accounts.width                  = 120
$accounts.height                 = 30
$accounts.location               = New-Object System.Drawing.Point(30,140)
$accounts.Font                   = 'Microsoft Sans Serif,10'

$msconfig                        = New-Object system.Windows.Forms.Button
$msconfig.text                   = "Msconfig"
$msconfig.width                  = 120
$msconfig.height                 = 30
$msconfig.location               = New-Object System.Drawing.Point(200,100)
$msconfig.Font                   = 'Microsoft Sans Serif,10'

$reliabilityHistory              = New-Object system.Windows.Forms.Button
$reliabilityHistory.text         = "Reliability History"
$reliabilityHistory.width        = 120
$reliabilityHistory.height       = 30
$reliabilityHistory.location     = New-Object System.Drawing.Point(200,140)
$reliabilityHistory.Font         = 'Microsoft Sans Serif,10'

$eventViewer                     = New-Object system.Windows.Forms.Button
$eventViewer.text                = "EventViewer"
$eventViewer.width               = 120
$eventViewer.height              = 30
$eventViewer.location            = New-Object System.Drawing.Point(200,180)
$eventViewer.Font                = 'Microsoft Sans Serif,10'

$scripts                         = New-Object system.Windows.Forms.Label
$scripts.text                    = "Scripts:"
$scripts.AutoSize                = $true
$scripts.width                   = 25
$scripts.height                  = 10
$scripts.location                = New-Object System.Drawing.Point(20,250)
$scripts.Font                    = 'Microsoft Sans Serif,14,style=Bold'

$debloat                         = New-Object system.Windows.Forms.Button
$debloat.text                    = "Debloat"
$debloat.width                   = 120
$debloat.height                  = 30
$debloat.location                = New-Object System.Drawing.Point(30,290)
$debloat.Font                    = 'Microsoft Sans Serif,10'

$iconsTime                       = New-Object system.Windows.Forms.Button
$iconsTime.text                  = "Icons and Time"
$iconsTime.width                 = 120
$iconsTime.height                = 30
$iconsTime.location              = New-Object System.Drawing.Point(200,290)
$iconsTime.Font                  = 'Microsoft Sans Serif,10'

$setTiles                        = New-Object system.Windows.Forms.Button
$setTiles.text                   = "Set Tiles"
$setTiles.width                  = 120
$setTiles.height                 = 30
$setTiles.location               = New-Object System.Drawing.Point(370,290)
$setTiles.Font                   = 'Microsoft Sans Serif,10'

$tools                           = New-Object system.Windows.Forms.Label
$tools.text                      = "Tools:"
$tools.AutoSize                  = $true
$tools.width                     = 25
$tools.height                    = 10
$tools.location                  = New-Object System.Drawing.Point(20,360)
$tools.Font                      = 'Microsoft Sans Serif,14,style=Bold'

$rKill                           = New-Object system.Windows.Forms.Button
$rKill.text                      = "rKill"
$rKill.width                     = 120
$rKill.height                    = 30
$rKill.location                  = New-Object System.Drawing.Point(30,400)
$rKill.Font                      = 'Microsoft Sans Serif,10'

$adwCleaner                      = New-Object system.Windows.Forms.Button
$adwCleaner.text                 = "AdwCleaner"
$adwCleaner.width                = 120
$adwCleaner.height               = 30
$adwCleaner.location             = New-Object System.Drawing.Point(30,440)
$adwCleaner.Font                 = 'Microsoft Sans Serif,10'

$kvrt                            = New-Object system.Windows.Forms.Button
$kvrt.text                       = "KVRT"
$kvrt.width                      = 120
$kvrt.height                     = 30
$kvrt.location                   = New-Object System.Drawing.Point(30,480)
$kvrt.Font                       = 'Microsoft Sans Serif,10'

$systemCheck                     = New-Object system.Windows.Forms.Button
$systemCheck.text                = "System Check"
$systemCheck.width               = 120
$systemCheck.height              = 30
$systemCheck.location            = New-Object System.Drawing.Point(200,400)
$systemCheck.Font                = 'Microsoft Sans Serif,10'

$systemRepair                    = New-Object system.Windows.Forms.Button
$systemRepair.text               = "System Repair"
$systemRepair.width              = 120
$systemRepair.height             = 30
$systemRepair.location           = New-Object System.Drawing.Point(200,440)
$systemRepair.Font               = 'Microsoft Sans Serif,10'

$installers                      = New-Object system.Windows.Forms.Label
$installers.text                 = "Installers:"
$installers.AutoSize             = $true
$installers.width                = 25
$installers.height               = 10
$installers.location             = New-Object System.Drawing.Point(20,550)
$installers.Font                 = 'Microsoft Sans Serif,14,style=Bold'

$ErrorProvider1                  = New-Object system.Windows.Forms.ErrorProvider

$googleChrome                    = New-Object system.Windows.Forms.CheckBox
$googleChrome.text               = "Google Chrome"
$googleChrome.AutoSize           = $false
$googleChrome.width              = 150
$googleChrome.height             = 20
$googleChrome.location           = New-Object System.Drawing.Point(30,590)
$googleChrome.Font               = 'Microsoft Sans Serif,10'

$mozillaFirefox                  = New-Object system.Windows.Forms.CheckBox
$mozillaFirefox.text             = "Mozilla Firefox"
$mozillaFirefox.AutoSize         = $false
$mozillaFirefox.width            = 150
$mozillaFirefox.height           = 20
$mozillaFirefox.location         = New-Object System.Drawing.Point(30,610)
$mozillaFirefox.Font             = 'Microsoft Sans Serif,10'

$vlc                             = New-Object system.Windows.Forms.CheckBox
$vlc.text                        = "VLC Media Player"
$vlc.AutoSize                    = $false
$vlc.width                       = 150
$vlc.height                      = 20
$vlc.location                    = New-Object System.Drawing.Point(200,590)
$vlc.Font                        = 'Microsoft Sans Serif,10'

$adobeReader                     = New-Object system.Windows.Forms.CheckBox
$adobeReader.text                = "Adobe Reader DC"
$adobeReader.AutoSize            = $false
$adobeReader.width               = 150
$adobeReader.height              = 20
$adobeReader.location            = New-Object System.Drawing.Point(200,610)
$adobeReader.Font                = 'Microsoft Sans Serif,10'

$7zip                            = New-Object system.Windows.Forms.CheckBox
$7zip.text                       = "7-zip File Manager"
$7zip.AutoSize                   = $false
$7zip.width                      = 150
$7zip.height                     = 20
$7zip.location                   = New-Object System.Drawing.Point(200,630)
$7zip.Font                       = 'Microsoft Sans Serif,10'

$java                            = New-Object system.Windows.Forms.CheckBox
$java.text                       = "Java"
$java.AutoSize                   = $false
$java.width                      = 150
$java.height                     = 20
$java.location                   = New-Object System.Drawing.Point(200,650)
$java.Font                       = 'Microsoft Sans Serif,10'

$malwarebytes                    = New-Object system.Windows.Forms.CheckBox
$malwarebytes.text               = "Malwarebytes"
$malwarebytes.AutoSize           = $false
$malwarebytes.width              = 150
$malwarebytes.height             = 20
$malwarebytes.location           = New-Object System.Drawing.Point(370,590)
$malwarebytes.Font               = 'Microsoft Sans Serif,10'

$kasperskyIS                     = New-Object system.Windows.Forms.CheckBox
$kasperskyIS.text                = "Kaspersky Internet"
$kasperskyIS.AutoSize            = $false
$kasperskyIS.width               = 150
$kasperskyIS.height              = 20
$kasperskyIS.location            = New-Object System.Drawing.Point(370,610)
$kasperskyIS.Font                = 'Microsoft Sans Serif,10'

$nortonPremium                   = New-Object system.Windows.Forms.CheckBox
$nortonPremium.text              = "Norton Premium"
$nortonPremium.AutoSize          = $false
$nortonPremium.width             = 150
$nortonPremium.height            = 20
$nortonPremium.location          = New-Object System.Drawing.Point(370,630)
$nortonPremium.Font              = 'Microsoft Sans Serif,10'

$nortonDeluxe                    = New-Object system.Windows.Forms.CheckBox
$nortonDeluxe.text               = "Norton Deluxe"
$nortonDeluxe.AutoSize           = $false
$nortonDeluxe.width              = 150
$nortonDeluxe.height             = 20
$nortonDeluxe.location           = New-Object System.Drawing.Point(370,650)
$nortonDeluxe.Font               = 'Microsoft Sans Serif,10'

$mcafeeLiveSafe                  = New-Object system.Windows.Forms.CheckBox
$mcafeeLiveSafe.text             = "McAfee LiveSafe"
$mcafeeLiveSafe.AutoSize         = $false
$mcafeeLiveSafe.width            = 150
$mcafeeLiveSafe.height           = 20
$mcafeeLiveSafe.location         = New-Object System.Drawing.Point(370,670)
$mcafeeLiveSafe.Font             = 'Microsoft Sans Serif,10'

$installSelected                 = New-Object system.Windows.Forms.Button
$installSelected.text            = "Install Selected"
$installSelected.width           = 120
$installSelected.height          = 30
$installSelected.location        = New-Object System.Drawing.Point(200,700)
$installSelected.Font            = 'Microsoft Sans Serif,10'

$infoBox                         = New-Object system.Windows.Forms.TextBox
$infoBox.multiline               = $true
$infoBox.ReadOnly                = $true
$infoBox.width                   = 400
$infoBox.height                  = 100
$infoBox.location                = New-Object System.Drawing.Point(550,60)
$infoBox.Font                    = 'Microsoft Sans Serif,10'

$outputBox                       = New-Object system.Windows.Forms.TextBox
$outputBox.multiline             = $true
$outputBox.ReadOnly              = $true
$outputBox.ScrollBars            = "Vertical"
$outputBox.width                 = 400
$outputBox.height                = 500
$outputBox.location              = New-Object System.Drawing.Point(550,180)
$outputBox.Font                  = 'Microsoft Sans Serif,10'

$clearOutput                     = New-Object system.Windows.Forms.Button
$clearOutput.text                = "Clear Output"
$clearOutput.width               = 120
$clearOutput.height              = 30
$clearOutput.location            = New-Object System.Drawing.Point(679,700)
$clearOutput.Font                = 'Microsoft Sans Serif,10'
$clearOutput.Add_Click{$outputBox.Clear()}

$staplesRemoteToolkit.controls.AddRange(@($shortcuts,$windowsUpdate,$deviceManager,$stsFolder,$appsFeatures,$accounts,$msconfig,$reliabilityHistory,$eventViewer,$scripts,$debloat,$iconsTime,$setTiles,$tools,$rKill,$adwCleaner,$kvrt,$systemCheck,$systemRepair,$installers,$googleChrome,$mozillaFirefox,$vlc,$adobeReader,$7zip,$java,$malwarebytes,$kasperskyIS,$nortonPremium,$nortonDeluxe,$mcafeeLiveSafe,$installSelected,$outputBox,$clearOutput,$infoBox))

########################## System Information ##########################

$unitUser = (Get-CimInstance Win32_ComputerSystem | Select-Object PrimaryOwnerName | Format-Table -HideTableHeaders | Out-String).Trim()
$unitName = (Get-CimInstance Win32_ComputerSystem | Select-Object Name | Format-Table -HideTableHeaders | Out-String).Trim()
$unitManufacture = (Get-CimInstance Win32_ComputerSystem | Select-Object Manufacturer | Format-Table -HideTableHeaders | Out-String).Trim()
$unitModel = (Get-CimInstance Win32_ComputerSystem | Select-Object Model | Format-Table -HideTableHeaders | Out-String).Trim()
$unitSerial = (Get-CimInstance Win32_Bios | Select-Object SerialNumber | Format-Table -HideTableHeaders | Out-String).Trim()

if($unitSerial -eq 'Default string') {
    $unitSerial = 'N/A'
}

$infoBox.text = " Username: $unitUser `r`n Device name: $unitName `r`n Manufacture: $unitManufacture `r`n Model: $unitModel `r`n Serial: $unitSerial"

########################## Functions ##########################

# Add line to Output Text Box
function Add-OutputBoxLine {
    param ($Message)
    $outputBox.AppendText("$Message`r`n")
    $outputBox.Refresh()
    $outputBox.ScrollToCaret()
}

# Download files with progress
function downloadFile($url, $targetFile){
    New-Item -ItemType directory -Path C:\STS\Programs
    (New-Object Net.WebClient).DownloadFile("$url", "$targetFile")
}

########################## Variables ##########################

$stsPrograms = "C:\STS\Programs\"

$latestRKill = "https://raw.githubusercontent.com/justinchapdelaine/IT-Resources/master/Tools/rk.exe"
$latestAdwCleaner = "https://raw.githubusercontent.com/justinchapdelaine/IT-Resources/master/Tools/adw.exe"
$latestKVRT = "https://devbuilds.s.kaspersky-labs.com/devbuilds/KVRT/latest/full/KVRT.exe"

$latestChrome = "https://dl.google.com/chrome/install/latest/chrome_installer.exe"
$latestFirefox = "https://download-installer.cdn.mozilla.net/pub/firefox/releases/67.0.1/win64/en-US/Firefox%20Setup%2067.0.1.exe"
$latestVLC = "https://mirrors.syringanetworks.net/videolan/vlc/3.0.6/win64/vlc-3.0.6-win64.exe"
$latestAdobeReader = "http://ardownload.adobe.com/pub/adobe/reader/win/AcrobatDC/1901220034/AcroRdrDC1901220034_en_US.exe"
$latest7 = "https://www.7-zip.org/a/7z1900-x64.exe"
$latestJava = "https://sdlc-esd.oracle.com/ESD6/JSCDL/jdk/8u211-b12/478a62b7d4e34b78b671c754eaaf38ab/jre-8u211-windows-x64.exe?GroupName=JSC&FilePath=/ESD6/JSCDL/jdk/8u211-b12/478a62b7d4e34b78b671c754eaaf38ab/jre-8u211-windows-x64.exe&BHost=javadl.sun.com&File=jre-8u211-windows-x64.exe&AuthParam=1559726139_b1b8ffdd2489c57ca4e7f4ffb3e5d448&ext=.exe"
$latestMalwarebytes = "https://data-cdn.mbamupdates.com/web/mb3-setup-consumer/mb3-setup-consumer-3.7.1.2839-1.0.586-1.0.10894.exe"
$latestKIS = "https://trial.s.kaspersky-labs.com/registered/gcbq5sibr4608gbt0dpw/27c9b336/startup_14453.exe"
$latestNortonPremium = "https://lcdls.symantec.com/93639012/CXlwMQ0HR9DNR00RSDTAVsy/+/Abcb003MD/////%2F%26~%2F%26~%2F%26~%2F%26~%2F%26~%2F%26~%2F%26~%2F%26~%2F%26~%2F%26~/NSBUDownloader.exe?LNG=eng-USA&latest=true"
$latestNortonDeluxe = "https://lcdls.symantec.com/93639012/AynW7R0BGKNVU00FOAUEbimf+/AbcX003MD/////%2F%26~%2F%26~%2F%26~%2F%26~%2F%26~%2F%26~%2F%26~%2F%26~%2F%26~%2F%26~/NSDownloader.exe?LNG=eng-USA&latest=true"
$latestMcafeeLive = "https://download.mcafee.com/molbin/iss-loc/directoneclicktrial/1.0/1316/1.0.100.1/mcafee_trial_setup_520.0207_key.exe"

########################## Shortcuts ##########################

# Windows Update
$windowsUpdate.Add_Click(
    {    
        explorer ms-settings:windowsupdate
        Add-OutputBoxLine -Message 'Opening Windows Update...'
    }
)

# Account Management
$accounts.Add_Click(
    {    
        explorer ms-settings:otherusers
        Add-OutputBoxLine -Message 'Opening Accounts...'
    }
)

# Apps & Features
$appsFeatures.Add_Click(
    {    
        explorer ms-settings:appsfeatures
        Add-OutputBoxLine -Message 'Opening Apps & Features...'
    }
)

# Device Manager
$deviceManager.Add_Click(
    {
        Start-Process devmgmt.msc
        Add-OutputBoxLine -Message 'Opening Device Manager...'
    }
)

# Msconfig
$msconfig.Add_Click(
    {
        Start-Process msconfig
        Add-OutputBoxLine -Message 'Opening System Configuration...'
    }
)

# Reliability History
$reliabilityHistory.Add_Click(
    {
        Start-Process perfmon.exe /rel
        Add-OutputBoxLine -Message 'Opening Reliability History...'
    }
)

# Event Viewer
$eventViewer.Add_Click(
    {
        Start-Process eventvwr.msc
        Add-OutputBoxLine -Message 'Opening Event Viewer...'
    }
)

# STS Folder
$stsFolder.Add_Click(
    {
        explorer C:\STS\
        Add-OutputBoxLine -Message 'Opening STS Folder...'
    }
)

########################## Scripts ##########################

# Debloat 
# Currently only debloats Windows 10
$debloat.Add_Click(
    {
        # Disable automaic app installation
        Add-OutputBoxLine -Message 'Disable Consumer Experience (Automatically App Installation)'
        New-ItemProperty -Path HKLM:\Software\Policies\Microsoft\Windows\CloudContent -Name DisableWindowsConsumerFeatures -PropertyType DWord -Value 1 -Force

        # Disable suggestions in start
        Add-OutputBoxLine -Message 'Disable Suggestion In Start'
        New-ItemProperty -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager -Name SubscribedContent-338388Enabled -PropertyType DWord -Value 0 -Force

        Add-OutputBoxLine -Message 'This may take a few minutes...'

        Add-OutputBoxLine -Message '1. Removing Utilities'
        # Apps
        Get-AppxPackage *MicrosoftOfficeHub* | Remove-AppxPackage
        Get-AppxPackage *OneConnect* | Remove-AppxPackage
        Get-AppxPackage *Netflix* | Remove-AppxPackage
        Get-AppxPackage *AdobePhotoshopExpress* | Remove-AppxPackage
        Get-AppxPackage *DrawboardPDF* | Remove-AppxPackage
        Get-AppxPackage *PandoraMediaInc* | Remove-AppxPackage
        Get-AppxPackage *Phototastic* | Remove-AppxPackage
        Get-AppxPackage *Fitbit* | Remove-AppxPackage
        Get-AppxPackage *DolbyAccess* | Remove-AppxPackage
        Get-AppxPackage *BingTranslator* | Remove-AppxPackage
        Get-AppxPackage *Evernote* | Remove-AppxPackage
        Get-AppxPackage *DropboxOEM* | Remove-AppxPackage
        Get-AppxPackage *RemoteDesktop* | Remove-AppxPackage
        Get-AppxPackage *McAfeeSecurity* | Remove-AppxPackage
        Get-AppxPackage *SpotifyMusic* | Remove-AppxPackage

        Add-OutputBoxLine -Message '2. Removing Games'
        # Games
        Get-AppxPackage *Asphalt8Airborne* | Remove-AppxPackage
        Get-AppxPackage *CandyCrushSodaSaga* | Remove-AppxPackage
        Get-AppxPackage *FalloutShelter* | Remove-AppxPackage
        Get-AppxPackage *FarmVille2CountryEscape* | Remove-AppxPackage
        Get-AppxPackage *MinecraftUWP* | Remove-AppxPackage
        Get-AppxPackage *RoyalRevolt2* | Remove-AppxPackage
        Get-AppxPackage *Candy* | Remove-AppxPackage
        Get-AppxPackage *SimpleMahjong* | Remove-AppxPackage
        Get-AppxPackage *Spades* | Remove-AppxPackage
        Get-AppxPackage *SimpleSolitaire* | Remove-AppxPackage
        Get-AppxPackage *WildTangentGames* | Remove-AppxPackage
        Get-AppxPackage *HeartsDeluxe* | Remove-AppxPackage
        Get-AppxPackage *COOKINGFEVER* | Remove-AppxPackage

        Add-OutputBoxLine -Message '3. Removing Social Media'
        # Social Media
        Get-AppxPackage *Facebook* | Remove-AppxPackage
        Get-AppxPackage *Twitter* | Remove-AppxPackage
        Get-AppxPackage *LinkedIn* | Remove-AppxPackage
        Get-AppxPackage *WhatsAppDesktop* | Remove-AppxPackage

        Add-OutputBoxLine -Message '4. Removing Shopping'
        # Shopping Apps
        Get-AppxPackage *eBay* | Remove-AppxPackage
        Get-AppxPackage *Amazon* | Remove-AppxPackage
        Get-AppxPackage *Booking* | Remove-AppxPackage

        # Acer Specific
        if($unitManufacture -like '*Acer*') {
            Add-OutputBoxLine -Message '5. Removing Acer Specific'
            # Metro Apps
            Get-AppxPackage *UserExperienceImprovementProgram* | Remove-AppxPackage
            Get-AppxPackage *QuickAccess* | Remove-AppxPackage
            Get-AppxPackage *AcerRegistration* | Remove-AppxPackage
            Get-AppxPackage *AcerCollectionS* | Remove-AppxPackage
            # Programs
            (Get-WMIObject -Classname Win32_Product | Where-Object Name -Match  'Acer Jumpstart').UnInstall()
            (Get-WMIObject -Classname Win32_Product | Where-Object Name -Match  'User Experience Improvement Program Service').UnInstall()
            (Get-WMIObject -Classname Win32_Product | Where-Object Name -Match  'Amazon').UnInstall()
            (Get-WMIObject -Classname Win32_Product | Where-Object Name -Match  'Acer UEIP Framework').UnInstall()
            (Get-WMIObject -Classname Win32_Product | Where-Object Name -Match  'Acer Collection').UnInstall()
        }

        # HP Specific
        if ($unitManfucature -like '*HP*') {
            Add-OutputBoxLine -Message '5. Removing HP Specific'
            # Metro Apps
            Get-AppxPackage *HPJumpStart* | Remove-AppxPackage
            Get-AppxPackage *HPPrinterControl* | Remove-AppxPackage
            # Programs
            (Get-WMIObject -Classname Win32_Product | Where-Object Name -Match  'HP JumpStart Launch').UnInstall()
            (Get-WMIObject -Classname Win32_Product | Where-Object Name -Match  'HP JumpStart Bridge').UnInstall()
            (Get-WMIObject -Classname Win32_Product | Where-Object Name -Match  'HP Customer Experience Enhancements').UnInstall()
            (Get-WMIObject -Classname Win32_Product | Where-Object Name -Match  'HP Registration Service').UnInstall()
            (Get-WMIObject -Classname Win32_Product | Where-Object Name -Match  'ePrint SW').UnInstall()
            (Get-WMIObject -Classname Win32_Product | Where-Object Name -Match  'HP ePrint SW').UnInstall()
        }

        # Lenovo Specific
        if ($unitManufacture -like '*Lenovo*') {
            Add-OutputBoxLine -Message '5. Removing Lenovo Specific'
            # None yet
        }

        # Microsoft Specific
        if ($unitManufacture -like '*Microsoft*') {
            Add-OutputBoxLine -Message '5. Removing Microsoft Specific'
            # None yet
        }

        # Asus Specific
        if ($unitManufacture -like '*Asus*') {
            Add-OutputBoxLine -Message '5. Removing Asus Specific'
            # Metro Apps
            Get-AppxPackage *ASUSProductRegistrationProgram* | Remove-AppxPackage
            Get-AppxPackage *ASUSGIFTBOX* | Remove-AppxPackage
            # Programs
            (Get-WMIObject -Classname Win32_Product | Where-Object Name -Match  'ASUS Hello').UnInstall()
            (Get-WMIObject -Classname Win32_Product | Where-Object Name -Match  'ASUS Device Activation').UnInstall()
            (Get-WMIObject -Classname Win32_Product | Where-Object Name -Match  'ASUS GiftBox Service').UnInstall()
            (Get-WMIObject -Classname Win32_Product | Where-Object Name -Match  'ASUS ZenAnywhere').UnInstall()
        }

        # Dell Specific
        if ($unitManufacture -like '*Dell*') {
            Add-OutputBoxLine -Message '5. Removing Dell Specific'
            # Metro Apps
            # Programs
            (Get-WMIObject -Classname Win32_Product | Where-Object Name -Match  'Dropbox Update Helper').UnInstall()
            (Get-WMIObject -Classname Win32_Product | Where-Object Name -Match  'Dropbox 20 GB').UnInstall()
            (Get-WMIObject -Classname Win32_Product | Where-Object Name -Match  'Product Registration').UnInstall()
        }

        Add-OutputBoxLine -Message "Blaotware removal complete!`r`n"
    }
)

# Icons & Time
# Enable desktop icons and set time to auto
$iconsTime.Add_Click(
    {
        # Create desktop icons for This PC, User Files, and Recycle Bin
        $ErrorActionPreference = "SilentlyContinue"
        If ($Error) {$Error.Clear()}
        $RegistryPath = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced"
        If (Test-Path $RegistryPath) {
            $Res = Get-ItemProperty -Path $RegistryPath -Name "HideIcons"
            If (-Not($Res)) {
                New-ItemProperty -Path $RegistryPath -Name "HideIcons" -Value "0" -PropertyType DWORD -Force | Out-Null
            }
            $Check = (Get-ItemProperty -Path $RegistryPath -Name "HideIcons").HideIcons
            If ($Check -NE 0) {
                New-ItemProperty -Path $RegistryPath -Name "HideIcons" -Value "0" -PropertyType DWORD -Force | Out-Null
            }
        }
        $RegistryPath = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons"
        If (-Not(Test-Path $RegistryPath)) {
            New-Item -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer" -Name "HideDesktopIcons" -Force | Out-Null
            New-Item -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons" -Name "NewStartPanel" -Force | Out-Null
        }
        $RegistryPath = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons\NewStartPanel"
        If (-Not(Test-Path $RegistryPath)) {
            New-Item -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons" -Name "NewStartPanel" -Force | Out-Null
        }
        If (Test-Path $RegistryPath) {
            # This PC
            Add-OutputBoxLine -Message '1. Display This PC on Desktop.'
            $Res = Get-ItemProperty -Path $RegistryPath -Name "{20D04FE0-3AEA-1069-A2D8-08002B30309D}"
            If (-Not($Res)) {
                New-ItemProperty -Path $RegistryPath -Name "{20D04FE0-3AEA-1069-A2D8-08002B30309D}" -Value "0" -PropertyType DWORD -Force | Out-Null
            }
            $Check = (Get-ItemProperty -Path $RegistryPath -Name "{20D04FE0-3AEA-1069-A2D8-08002B30309D}")."{20D04FE0-3AEA-1069-A2D8-08002B30309D}"
            If ($Check -NE 0) {
                New-ItemProperty -Path $RegistryPath -Name "{20D04FE0-3AEA-1069-A2D8-08002B30309D}" -Value "0" -PropertyType DWORD -Force | Out-Null
            }
            # User Files
            Add-OutputBoxLine -Message '2. Display User folder on Desktop.'
            $Res = Get-ItemProperty -Path $RegistryPath -Name "{59031a47-3f72-44a7-89c5-5595fe6b30ee}"
            If (-Not($Res)) {
                New-ItemProperty -Path $RegistryPath -Name "{59031a47-3f72-44a7-89c5-5595fe6b30ee}" -Value "0" -PropertyType DWORD -Force | Out-Null
            }
            $Check = (Get-ItemProperty -Path $RegistryPath -Name "{59031a47-3f72-44a7-89c5-5595fe6b30ee}")."{59031a47-3f72-44a7-89c5-5595fe6b30ee}"
            If ($Check -NE 0) {
                New-ItemProperty -Path $RegistryPath -Name "{59031a47-3f72-44a7-89c5-5595fe6b30ee}" -Value "0" -PropertyType DWORD -Force | Out-Null
            }
            # Recycle Bin
            Add-OutputBoxLine -Message '2. Display Recycle Bin on Desktop.'
            $Res = Get-ItemProperty -Path $RegistryPath -Name "{645FF040-5081-101B-9F08-00AA002F954E}"
            If (-Not($Res)) {
                New-ItemProperty -Path $RegistryPath -Name "{645FF040-5081-101B-9F08-00AA002F954E}" -Value "0" -PropertyType DWORD -Force | Out-Null
            }
            $Check = (Get-ItemProperty -Path $RegistryPath -Name "{645FF040-5081-101B-9F08-00AA002F954E}")."{645FF040-5081-101B-9F08-00AA002F954E}"
            If ($Check -NE 0) {
                New-ItemProperty -Path $RegistryPath -Name "{645FF040-5081-101B-9F08-00AA002F954E}" -Value "0" -PropertyType DWORD -Force | Out-Null
            }
        }
        If ($Error) {$Error.Clear()}

        # Set Time and Time Zone to automatic
        Add-OutputBoxLine -Message '3. Set Time and Time Zone to automaic.'
        New-ItemProperty -Path HKLM:\SYSTEM\CurrentControlSet\Services\W32Time\Parameters -Name Type -PropertyType String -Value NTP -Force
        New-ItemProperty -Path HKLM:\SYSTEM\CurrentControlSet\Services\tzautoupdate -Name Start -PropertyType DWord -Value 3 -Force
    
        # Restart explorer to refresh desktop
        Add-OutputBoxLine -Message '4. Restart explorer to refresh desktop.'
        Stop-Process -Name explorer

        Add-OutputBoxLine -Message "Desktop icons and time are set!`r`n"
    }
)

# Set Tiles
# Set Windows 10 Tiles in specific configuration
$setTiles.Add_Click(
    {
        ########## TODO ##########
    }
)

########################## Tools ##########################

# rKill
$rKill.Add_Click(
    {
        Add-OutputBoxLine -Message '1. Downloading rKill...'
        downloadFile "$latestRKill" "$stsPrograms\rKill.exe"
        Add-OutputBoxLine -Message "2. Starting rKill...`r`n"
        Start-Process -FilePath "$stsPrograms\rKill.exe"
    }
)

# AdwCleaner
$adwCleaner.Add_Click(
    {
        Add-OutputBoxLine -Message '1. Downloading AdwCleaner...'
        downloadFile "$latestAdwCleaner" "$stsPrograms\AdwCleaner.exe"
        Add-OutputBoxLine -Message "2. Starting AdwCleaner...`r`n"
        Start-Process -FilePath "$stsPrograms\AdwCleaner.exe"
    }
)

# Kaspersky Virus Removal Tool
$kvrt.Add_Click(
    {
        Add-OutputBoxLine -Message '1. Downloading KVRT...'
        downloadFile "$latestKVRT" "$stsPrograms\KVRT.exe"
        Add-OutputBoxLine -Message "2. Starting KVRT...`r`n"
        Start-Process -FilePath "$stsPrograms\KVRT.exe" -ArgumentList "-accepteula"
    }
)

# Check disk partition and Windows integrity
$systemCheck.Add_Click(
    {
        # Check for disk partition errors
        $output = Repair-Volume -DriveLetter C
        Add-OutputBoxLine -Message "Disk Check: $output"

        # Check Windows integrity
        $output = ($(sfc /verifyonly) -split '' | ? {$_ -and [byte][char]$_ -ne 0}) -join ''
        Add-OutputBoxLine -Message "Windows Integrity: $output"
    }
)

# Repair disk partition and Windows integrity
$systemRepair.Add_Click(
    {
        # Repair disk partition errors
        $output = Repair-Volume -DriveLetter C -Scan
        Add-OutputBoxLine -Message "Disk Repair: $output"

        # Repair dism image
        $output = DISM.exe /Online /Cleanup-image /Restorehealth /LogLevel:3

        # Check Windows integrity
        $output = ($(sfc /scannow) -split '' | ? {$_ -and [byte][char]$_ -ne 0}) -join ''
        Add-OutputBoxLine -Message "Windows Integrity: $output"
    }
)

########################## Installers ##########################

# Google Chrome
$googleChrome.Add_Click(
    {
        $progName = 'Google Chrome'
        Add-OutputBoxLine -Message "1. Downloading $progName..."
        downloadFile "$latestChrome" "$stsPrograms\$progName.exe"
        Add-OutputBoxLine -Message "2. Installing $progName...`r`n"
        Start-Process -FilePath "$stsPrograms\$progName.exe" -ArgumentList "/silent /install"
    }
)

# Mozilla Firefox
$mozillaFirefox.Add_Click(
    {
        $progName = 'Mozilla Firefox'
        Add-OutputBoxLine -Message "1. Downloading $progName..."
        downloadFile "$latestFirefox" "$stsPrograms\$progName.exe"
        Add-OutputBoxLine -Message "2. Installing $progName...`r`n"
        Start-Process -FilePath "$stsPrograms\$progName.exe" -ArgumentList "-ms"
    }
)

# VLC Media Player
$vlc.Add_Click(
    {
        $progName = 'VLC Media Player'
        Add-OutputBoxLine -Message "1. Downloading $progName..."
        downloadFile "$latestVLC" "$stsPrograms\$progName.exe"
        Add-OutputBoxLine -Message "2. Installing $progName...`r`n"
        Start-Process -FilePath "$stsPrograms\$progName.exe" -ArgumentList "/L=1033 /S"
    }
)

# Adobe Reader DC
$adobeReader.Add_Click(
    {
        $progName = 'Adobe Reader DC'
        Add-OutputBoxLine -Message "1. Downloading $progName..."
        downloadFile "$latestAdobeReader" "$stsPrograms\$progName.exe"
        Add-OutputBoxLine -Message "2. Installing $progName...`r`n"
        Start-Process -FilePath "$stsPrograms\$progName.exe" -ArgumentList "/sAll /rs"
    }
)

# 7-zip File Manager
$7zip.Add_Click(
    {
        $progName = '7-zip File Manager'
        Add-OutputBoxLine -Message "1. Downloading $progName..."
        downloadFile "$latest7" "$stsPrograms\$progName.exe"
        Add-OutputBoxLine -Message "2. Installing $progName...`r`n"
        Start-Process -FilePath "$stsPrograms\$progName.exe" -ArgumentList "/S /D="%PROGRAMFILES%\7-Zip""
    }
)

# Java Runtime Environment
$java.Add_Click(
    {
        $progName = 'Java'
        Add-OutputBoxLine -Message "1. Downloading $progName..."
        downloadFile "$latestJava" "$stsPrograms\$progName.exe"
        Add-OutputBoxLine -Message "2. Installing $progName...`r`n"
        Start-Process -FilePath "$stsPrograms\$progName.exe" -ArgumentList "INSTALL_SILENT=Enable"
    }
)

# Malwarebytes Anti-Malware
$malwarebytes.Add_Click(
    {
        $progName = 'Malwarebytes'
        Add-OutputBoxLine -Message "1. Downloading $progName..."
        downloadFile "$latestMalwarebytes" "$stsPrograms\$progName.exe"
        Add-OutputBoxLine -Message "2. Installing $progName...`r`n"
        Start-Process -FilePath "$stsPrograms\$progName.exe" -ArgumentList "/verysilent /nocancel /suppressmsgboxes /norestart"
    }
)

# Kaspersky Internet Security
$kasperskyIS.Add_Click(
    {
        $progName = 'Kaspersky Internet Security'
        Add-OutputBoxLine -Message "1. Downloading $progName..."
        downloadFile "$latestKIS" "$stsPrograms\$progName.exe"
        Add-OutputBoxLine -Message "2. Installing $progName...`r`n"
        Start-Process -FilePath "$stsPrograms\$progName.exe"
    }
)

# Norton Premium Security
$nortonPremium.Add_Click(
    {
        $progName = 'Norton Premium Security'
        Add-OutputBoxLine -Message "1. Downloading $progName..."
        downloadFile "$latestNortonPremium" "$stsPrograms\$progName.exe"
        Add-OutputBoxLine -Message "2. Installing $progName...`r`n"
        Start-Process -FilePath "$stsPrograms\$progName.exe"
    }
)

# Norton Dexluxe Security
$nortonDeluxe.Add_Click(
    {
        $progName = 'Norton Deluxe Security'
        Add-OutputBoxLine -Message "1. Downloading $progName..."
        downloadFile "$latestNortonDeluxe" "$stsPrograms\$progName.exe"
        Add-OutputBoxLine -Message "2. Installing $progName...`r`n"
        Start-Process -FilePath "$stsPrograms\$progName.exe"
    }
)

# McAfee LiveSafe
$mcafeeLiveSafe.Add_Click(
    {
        $progName = 'McAfee LiveSafe'
        Add-OutputBoxLine -Message "1. Downloading $progName..."
        downloadFile "$latestMcafeeLive" "$stsPrograms\$progName.exe"
        Add-OutputBoxLine -Message "2. Installing $progName...`r`n"
        Start-Process -FilePath "$stsPrograms\$progName.exe"
    }
)


########################## EOF Create GUI Window ##########################

[void]$staplesRemoteToolkit.ShowDialog()